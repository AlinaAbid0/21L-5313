package com.example.splash;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ResultActivity extends AppCompatActivity {

    private TextView resultText;
    private Button shareButton;

    private int score;
    private int totalQuestions;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        // Initialize UI elements
        resultText = findViewById(R.id.resultText);
        shareButton = findViewById(R.id.shareButton);

        // Get the score and total questions from the intent
        Intent intent = getIntent();
        score = intent.getIntExtra("SCORE", 0);
        totalQuestions = intent.getIntExtra("TOTAL_QUESTIONS", 1);

        // Display the result
        resultText.setText("Your Score: " + score + "/" + totalQuestions);

        // Set click listener for the Share Score button
        shareButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shareScore();
            }
        });
    }

    private void shareScore() {
        // Create a message to share
        String shareMessage = "I scored " + score + " out of " + totalQuestions + " in the quiz!";

        // Create an Implicit Intent to share the score
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);

        // Start the share activity
        startActivity(Intent.createChooser(shareIntent, "Share via"));
    }
}