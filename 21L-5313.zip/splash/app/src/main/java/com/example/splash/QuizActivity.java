package com.example.splash;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class QuizActivity extends AppCompatActivity {

    private TextView userNameTextView; // New TextView to display username

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        // Retrieve the username from the intent
        String userName = getIntent().getStringExtra("USER_NAME");

        // Find the TextView for username
        userNameTextView = findViewById(R.id.userNameTextView); // Make sure this ID exists in activity_quiz.xml

        // Display the username
        if (userName != null) {
            userNameTextView.setText("Welcome, " + userName + "!");
        }
    }
}
